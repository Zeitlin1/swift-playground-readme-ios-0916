//: Playground - noun: a place where people can play

var str = "Hello, playground"

str = "What's Up!"
